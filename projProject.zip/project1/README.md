# opengl-raycast-engine
A simple fixed pitch ray-casting engine (similar to the rendering of wolfenstein and Doom) utilizing the GLUT OpenGL library


Created by:

Anthony Harris		(Heads Up Display)
Paul Durham		(Assets)	
Devlyn Hogue III	(Death Screen)
Gage Coates		(3D Rendering)

Last Modified:

16 October 2019
09:05

Requirements:

Line Segments		Fulfilled by line over bottom section of HUD
Pattern Filled Polygon	Fulfilled by tile background of HUD
Circle			Fulfilled by reticle
Bitmap			Fulfilled by Omega Gaming Project symbol
Pixel Map		Fulfilled by the player icon in HUD
Text			Fulfilled by death screen