#include "pch.h"
#include "Region.h"

Region::Region()
{
}
